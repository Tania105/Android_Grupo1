package com.example.miincidencia.adapters

import com.example.miincidencia.Dataclases.PerfilDataResponse

class perfilAdapter(var perfil:PerfilDataResponse) {
    fun perfil(a:PerfilDataResponse){
        this.perfil=a;
    }
}
