package com.example.miincidencia.listadoIncidencias

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.example.miincidencia.IncidenciaAdapter
import com.example.miincidencia.IncidenciaDataResponse
import com.example.miincidencia.R
import com.example.miincidencia.api.ApiService
import com.example.miincidencia.configuracion.ConfiguracionActivity
import com.example.miincidencia.databinding.FragmentBienvenidoBinding
import com.example.miincidencia.databinding.FragmentNuevoBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class NuevoFragment : Fragment() {
    lateinit var binding: FragmentNuevoBinding
    private lateinit var retrofit: Retrofit
    private lateinit var adapter: IncidenciaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentNuevoBinding.inflate(inflater, container, false)
        // Inflar el layout del fragmento
        initUi()


        return binding.root
    }
    private fun initUi(){
        setHasOptionsMenu(true)
        // Configurar la barra de acciones para mostrar el botón de "volver"
        val activity = requireActivity() as AppCompatActivity
        retrofit = getRetrofit()
        }

    fun searchByName(query: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val myResponse: Response<IncidenciaDataResponse> =
                retrofit.create(ApiService::class.java).getIncidencias(query)
            if (myResponse.isSuccessful) {
                Log.i("aristidevs", "funciona :)")
                val response: IncidenciaDataResponse? = myResponse.body()
                if (response != null) {
                    Log.i("aristidevs", response.toString())
                    requireActivity().runOnUiThread {
                        adapter.updateList(response.incidencias)
                    }
                }
            } else {
                Log.i("aristidevs", "No funciona :(")
            }
        }


    }
    private fun getRetrofit(): Retrofit {
        return Retrofit
            .Builder()
            .baseUrl("https://rickandmortyapi.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    }


