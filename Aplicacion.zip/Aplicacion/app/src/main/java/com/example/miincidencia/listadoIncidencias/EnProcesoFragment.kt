package com.example.miincidencia.listadoIncidencias

import androidx.fragment.app.Fragment
import com.example.miincidencia.R

/**
 * A simple [Fragment] subclass.
 * Use the [EnProcesoFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class EnProcesoFragment : Fragment(R.layout.fragment_en_proceso) {

}