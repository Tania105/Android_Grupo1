package com.example.miincidencia

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.miincidencia.api.IncidenciaViewHolder


class IncidenciaAdapter(
    var incidenciaList: List<IncidenciaItemResponse> = emptyList(),
    private val onItemSelected: (String) -> Unit
) :
    RecyclerView.Adapter<IncidenciaViewHolder>() {

    fun updateList(list: List<IncidenciaItemResponse>) {
        incidenciaList = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncidenciaViewHolder {
        return IncidenciaViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_incidencia, parent, false)
        )
    }

    override fun onBindViewHolder(viewholder: IncidenciaViewHolder, position: Int) {
        viewholder.bind(incidenciaList[position],onItemSelected)
    }

    override fun getItemCount() = incidenciaList.size


}