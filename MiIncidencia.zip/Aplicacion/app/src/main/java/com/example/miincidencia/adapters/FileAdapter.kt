package com.example.miincidencia

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File


class FileAdapter (private var files: MutableList<File>) : RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

    inner class FileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fileNameTextView: TextView = itemView.findViewById(R.id.txtTituloAdjunto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_adjunto, parent, false)
        return FileViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        val file = files[position]
        Log.d("Nombre del archivo", file.name)
        holder.fileNameTextView.text = file.name
    }

    override fun getItemCount(): Int {
        return files.size
    }

    fun addFile(file: File) {
        files.add(file)
        notifyItemInserted(files.size - 1)
    }
}
