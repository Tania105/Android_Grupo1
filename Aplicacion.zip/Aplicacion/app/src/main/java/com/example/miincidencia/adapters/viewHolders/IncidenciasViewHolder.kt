package com.example.miincidencia.adapters.viewHolders

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.miincidencia.Dataclases.IncidenciaDataResponse
import com.example.miincidencia.databinding.ItemIncidenciaBinding

class IncidenciasViewHolder(view: View) :RecyclerView.ViewHolder(view){
    private val binding=ItemIncidenciaBinding.bind(view)
fun bind(incidenciaDataResponse:IncidenciaDataResponse){
binding.txtCodigoIncidencia.text=incidenciaDataResponse.num.toString()
    binding.txtEstadoIncidencia.text=incidenciaDataResponse.Estado
    binding.txtTituloIncidencia.text=incidenciaDataResponse.tipo
}
}