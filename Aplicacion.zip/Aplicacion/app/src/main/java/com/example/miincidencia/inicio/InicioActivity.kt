package com.example.miincidencia.inicio

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.widget.Button
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.get
import com.example.miincidencia.Dataclases.PerfilDataResponse
import com.example.miincidencia.MainActivity
import com.example.miincidencia.R
import com.example.miincidencia.api.ApiService
import com.example.miincidencia.databinding.ActivityInicioBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.Thread.sleep

class InicioActivity : AppCompatActivity() {
    var url:String="http://192.168.0.20:8089/api/"
    lateinit var binding : ActivityInicioBinding
   private lateinit var retrofit: Retrofit

    companion object {
        const val LOCATION_REQUEST_CODE =  1000 // Choose a unique number for your request code
        const val CHANNEL_ID : String = "your_channel_id"
        var perfil: PerfilDataResponse?=null
    }

    @SuppressLint("SuspiciousIndentation")
    private fun createNotificationChannel() {
        val channelName = "Your Channel Name"
        val channelDescription = "Channel Description"
        val importance = NotificationManager.IMPORTANCE_HIGH
        val channel = NotificationChannel(CHANNEL_ID, channelName, importance).apply {
            description = channelDescription
        }
        val notificationManager: NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun sendNotification(context: Context, title: String, description: String) {
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground) // Replace with your notification icon
            .setContentTitle(title)
            .setContentText(description)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), LOCATION_REQUEST_CODE)
        } else {
            // Permission already granted, proceed with the operation
            with(NotificationManagerCompat.from(context)) {
                notify(System.currentTimeMillis().toInt(), builder.build())
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInicioBinding.inflate(layoutInflater)
        setContentView(binding.root)
        retrofit=getRetrofit()

        // Call this method to create the notification channel
        createNotificationChannel()
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            sendNotification(this, "Prueba", "Esto es una prueba")
        }

        //The btnInicioSesion is the button that will take us to the Main Interface
        binding.btnInicioSesion.setOnClickListener()
        {

            inicioSesion(binding.edtUsuario.editText?.text.toString(),binding.edtPassword.editText?.text.toString())
            sleep(100)
            if (perfil != null) {

                Log.i("pruebas perfil", perfil.toString() )
                var intent=Intent(this, MainActivity::class.java)
                MainActivity.Companion.url=this.url
                MainActivity.Companion.perfil=perfil
                startActivity(intent)
            }

    }}

    fun inicioSesion(educantabria: String, password:String){
        CoroutineScope(Dispatchers.IO).launch {
            val myResponse: Response<PerfilDataResponse> =retrofit.create(ApiService::class.java)
                .getPerfilByEducantabriaAndPass(educantabria, password)
            if (myResponse.isSuccessful){
                val response : PerfilDataResponse?= myResponse.body()
                if (response!=null){
                    Log.i("pruebas", response.toString())
                    perfil=response
                    sleep(200)
                }
            }

        }

    }

}
fun getRetrofit(): Retrofit {
    return Retrofit.Builder().baseUrl("http://192.168.0.20:8089/api/")
        .addConverterFactory(GsonConverterFactory.create()).build()


}
