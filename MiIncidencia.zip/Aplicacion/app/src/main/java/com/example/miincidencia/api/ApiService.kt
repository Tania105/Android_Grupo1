package com.example.miincidencia.api

import com.example.miincidencia.IncidenciaDataResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {

    @GET("/api/character/")
    suspend fun getIncidencias(@Path("id") superheroName:String):Response<IncidenciaDataResponse>

}