package com.example.miincidencia.listadoIncidencias

import androidx.fragment.app.Fragment
import com.example.miincidencia.R

class NuevoFragment : Fragment(R.layout.fragment_nuevo) {

}