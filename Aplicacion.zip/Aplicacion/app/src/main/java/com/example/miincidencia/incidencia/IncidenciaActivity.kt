package com.example.miincidencia.incidencia


import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.databinding.tool.util.FileUtil
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.util.AttributeSet
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.miincidencia.FileAdapter
import com.example.miincidencia.R
import com.example.miincidencia.databinding.ActivityIncidenciaBinding
import com.example.miincidencia.incidencia.IncidenciaIniActivity.Companion.FICHERO
import kotlinx.coroutines.CoroutineStart
import java.io.File
import java.io.FileOutputStream
import android.util.Base64
import android.widget.EditText
import androidx.core.view.get
import com.example.miincidencia.Dataclases.IncidenciaDataResponse
import com.example.miincidencia.MainActivity

import com.example.miincidencia.adapters.IncidenciasAdapter


class IncidenciaActivity : AppCompatActivity() {
    lateinit var binding: ActivityIncidenciaBinding
    lateinit var adapter : FileAdapter
    lateinit var file: File
     var posi:Int=0
    lateinit var inci:IncidenciaDataResponse
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        posi= posicion
        inci=MainActivity.lista[posi]
        binding = ActivityIncidenciaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        adapter = FileAdapter(ArrayList())
        binding.listaAdjuntos.adapter = adapter
        binding.listaAdjuntos.layoutManager = LinearLayoutManager(this)
        // Habilita el botón de retroceso en la barra de acción
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.apply{
            title = "Ver Incidencia"
        }


    initUI()
    }

    private fun initUI(){
        inci=MainActivity.lista[posicion]
        binding.edtTituloIncidencia.setText(inci.num.toString())
        binding.edtDescripcion.setText(inci.Descripcion.toString())




        mostrarMas()
    }

    private fun mostrarMas(){
        binding.btnMostrar.setOnClickListener {
            // Cambiar la visibilidad de la CardView y la RecyclerView
            if (binding.txtAdjuntos.visibility == View.VISIBLE) {
                binding.txtAdjuntos.visibility = View.GONE
                binding.listaAdjuntos.visibility = View.GONE
                binding.btnMostrar.text = "Mostrar Más"
            } else {
                binding.txtAdjuntos.visibility = View.VISIBLE
                binding.listaAdjuntos.visibility = View.VISIBLE
                binding.btnMostrar.text = "Mostrar Menos"
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_crear, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.aceptar -> {
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Aviso")
                builder.setMessage("¿Esta seguro de crear la incidencia?")
                builder.setPositiveButton("Si") { dialog, which ->
                    finish()
                }
                builder.setNegativeButton("No") { dialog, which ->
                    // Código para manejar la acción al presionar el botón "Cancelar"
                }
                val dialog = builder.create()
                dialog.show()
                true
            }
            R.id.adjuntar -> {
                val intent = Intent(Intent.ACTION_GET_CONTENT)
                // Permitir los tipos de archivo deseados
                intent.type = "*/*"
                intent.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // Excel
                    "application/msword", // Word
                    "image/png", // PNG
                    "image/jpeg", // JPG
                    "application/pdf" // PDF
                ))
                startActivityForResult(intent, FICHERO)
                true
            }
            android.R.id.home -> {
                // Maneja el botón de retroceso
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Aviso")
                builder.setMessage("¿Quiere descartar los cambios?")
                builder.setPositiveButton("Si") { dialog, which ->
                    finish()
                }
                builder.setNegativeButton("No") { dialog, which ->
                    // Código para manejar la acción al presionar el botón "Cancelar"
                }
                val dialog = builder.create()
                dialog.show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FICHERO && resultCode == Activity.RESULT_OK) {
            // Obtener la URI del archivo seleccionado
            val fileUri = data?.data
            fileUri?.let { uri ->
                val selectedFile = getFileFromUri(uri)
                if (selectedFile != null) {
                    // Haz algo con el archivo seleccionado
                    adapter.addFile(selectedFile)
                    file = selectedFile
                } else {
                    // Maneja el caso en el que no se pueda obtener el archivo
                }
            }
        }
    }

    private fun getFileFromUri(uri: Uri): File? {
        val contentResolver = applicationContext.contentResolver
        val inputStream = contentResolver.openInputStream(uri)
        val fileName = getFileNameFromUri(uri) // Obtener el nombre real del archivo

        inputStream?.use { input ->
            val file = File(cacheDir, fileName)
            FileOutputStream(file).use { output ->
                input.copyTo(output)
            }
            return file
        }
        return null
    }
    private fun getFileNameFromUri(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val displayNameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (displayNameIndex != -1) {
                    return it.getString(displayNameIndex)
                }
            }
        }
        return "archivo_desconocido" // Si no se puede obtener el nombre real, devuelve un nombre genérico
    }

    fun uploadFileToApi(file: File) {
        // Lee el contenido del archivo y conviértelo en un arreglo de bytes
        val fileBytes = file.readBytes()

        // Convierte el arreglo de bytes a una cadena Base64
        val base64String = Base64.encodeToString(fileBytes, Base64.DEFAULT)

        // Envía la cadena Base64 a tu API en el cuerpo de la solicitud
        // Aquí debes escribir el código para realizar la solicitud a tu API
        // por ejemplo, utilizando Retrofit, Volley, etc.
        // Asumiendo que tienes una función en tu API que acepta una cadena Base64
        // y realiza la subida del archivo, podrías hacer algo así:
        // apiService.uploadFile(base64String).enqueue(...)
    }

    companion object{
        val FICHERO = 0
         var posicion:Int=0
    }
}