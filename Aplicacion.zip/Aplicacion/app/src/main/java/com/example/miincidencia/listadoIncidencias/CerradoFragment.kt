package com.example.miincidencia.listadoIncidencias

import androidx.fragment.app.Fragment
import com.example.miincidencia.R

/**
 * A simple [Fragment] subclass.
 * Use the [CerradoFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class CerradoFragment : Fragment(R.layout.fragment_cerrado) {

}