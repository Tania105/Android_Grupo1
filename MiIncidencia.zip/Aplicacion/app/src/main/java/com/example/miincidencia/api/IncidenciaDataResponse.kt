package com.example.miincidencia

import com.google.gson.annotations.SerializedName

data class IncidenciaDataResponse(
    @SerializedName("info") val response: String,
    @SerializedName("results") val incidencias: List<IncidenciaItemResponse>
)

data class IncidenciaItemResponse(
    @SerializedName("id") val incidenciaId: String,
    @SerializedName("name") val name: String,
    @SerializedName("status") val status: String,
    @SerializedName("image") val incidenciaImage:IncidenciaImageResponse
)

data class IncidenciaImageResponse(@SerializedName("url") val url:String)