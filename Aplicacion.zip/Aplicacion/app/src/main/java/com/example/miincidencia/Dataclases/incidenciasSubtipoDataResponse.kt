package com.example.miincidencia.Dataclases

import com.google.gson.annotations.SerializedName

data class incidenciasSubtipoDataResponse(
    @SerializedName("id") val id: Long,
    @SerializedName("tipo") val tipo: String,
    @SerializedName("subtipo_nombre") val subtipo_nombre: String,
    @SerializedName("sub_subtipo") val sub_subtipo: String?,
)