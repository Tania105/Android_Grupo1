package com.example.miincidencia.api

import com.example.miincidencia.Dataclases.IncidenciaDataResponse
import com.example.miincidencia.Dataclases.PerfilDataResponse
import com.example.miincidencia.Dataclases.incidenciasSubtipoDataResponse

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("perfiles/validacion")
    suspend fun getPerfilByEducantabriaAndPass(@Query("educantabria") educantabria:String,@Query("password") password:String):Response<PerfilDataResponse>
    @GET("incidencias")
    suspend fun getIncidencias():Response<List<IncidenciaDataResponse>>
    @GET("incidencias/creadorId/{id}")
    suspend fun getPorCreador(@Query("id")id:Long):Response<List<IncidenciaDataResponse>>
    @GET("incidencias/activas")
    suspend fun getActiveIncidencias():Response<List<IncidenciaDataResponse>>
    @GET("incidenciasSubtipos")
    suspend fun getSubtipos():Response<List<incidenciasSubtipoDataResponse>>
}