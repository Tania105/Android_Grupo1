package com.example.miincidencia.api

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.miincidencia.IncidenciaItemResponse
import com.example.miincidencia.databinding.ItemIncidenciaBinding
import com.squareup.picasso.Picasso

class IncidenciaViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    private val binding = ItemIncidenciaBinding.bind(view)

    fun bind(incidenciaItemResponse: IncidenciaItemResponse, onItemSelected: (String) -> Unit) {
        binding.txtTituloIncidencia.text = incidenciaItemResponse.name
        Picasso.get().load(incidenciaItemResponse.incidenciaImage.url).into(binding.imgIncidencia)
        binding.root.setOnClickListener { onItemSelected(incidenciaItemResponse.incidenciaId) }
    }
}