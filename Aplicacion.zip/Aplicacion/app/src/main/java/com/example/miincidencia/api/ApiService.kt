package com.example.miincidencia.api

import com.example.miincidencia.Dataclases.IncidenciaDataResponse
import com.example.miincidencia.Dataclases.PerfilDataResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("perfiles/validacion")
    suspend fun getPerfilByEducantabriaAndPass(@Query("educantabria") educantabria:String,@Query("password") password:String):Response<PerfilDataResponse>

    @GET("incidencias/activas")
    suspend fun getActiveIncidencias():Response<List<IncidenciaDataResponse>>
    @GET("incidencias/estado")
    suspend fun getPorEstado(@Query("parametros")estado:String):Response<List<IncidenciaDataResponse>>
}