package com.example.miincidencia.Dataclases

import com.google.gson.annotations.SerializedName
import java.util.Date

data class IncidenciaDataResponse(
    @SerializedName("num") val num: Long,
    @SerializedName("tipo") val tipo: String,
    @SerializedName("subtipo_id") val subtipo: incidenciasSubtipoDataResponse,//subtipo
    @SerializedName("fecha_inicio") val fecha_inicio: java.sql.Date,
    @SerializedName("fecha_cierre") val fecha_cierre: java.sql.Date,
    @SerializedName("Descripcion") val Descripcion: String,
    @SerializedName("estado") val Estado: String,
    @SerializedName("adjunto_url") val adjunto_url: String,
    @SerializedName("creadorId") val Creador:personalDataResponse,//personal
    @SerializedName("responsable_id") val responsable: personalDataResponse,//personal
    @SerializedName("equipoId") val equipo: equipoDataResponse,//equipo
    @SerializedName("tiempo") val Tiempo: java.sql.Time,

    )
