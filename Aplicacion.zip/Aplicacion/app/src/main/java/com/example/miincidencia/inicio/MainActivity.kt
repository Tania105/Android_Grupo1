package com.example.miincidencia.inicio

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.miincidencia.Dataclases.IncidenciaDataResponse
import com.example.miincidencia.notificaciones.NotificacionesFragment
import com.example.miincidencia.R
import com.example.miincidencia.databinding.ActivityMainBinding
import com.example.miincidencia.listadoIncidencias.ListaIncidenciasFragment
import com.example.miincidencia.Dataclases.PerfilDataResponse
import com.example.miincidencia.Dataclases.incidencias
import com.example.miincidencia.api.ApiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit

class MainActivity : AppCompatActivity(){

    lateinit var binding : ActivityMainBinding
    lateinit var listaIncidenciasFragment : ListaIncidenciasFragment
    lateinit var bienvenidoFragment: BienvenidoFragment

    lateinit var notificacionesFragment: NotificacionesFragment
    //opcion de no hacer tantas peticiones a la api, se hace una con todas tus peticoniones y se filtran en codigo
  //  lateinit var Filtradorincidencias: incidencias
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initComponents()
        initUI()


    }

    private fun initUI(){
        seleccionarToolbar()


    }

    private fun initComponents(){
        listaIncidenciasFragment = ListaIncidenciasFragment()
        bienvenidoFragment = BienvenidoFragment()
        notificacionesFragment = NotificacionesFragment()
    }

    private fun setCurrentFragment(fragment: Fragment){
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.containerView,fragment)
            commit()
        }
    }
    private fun seleccionarToolbar(){
        binding.navegacion.setOnNavigationItemSelectedListener{
            when(it.itemId){
                R.id.incidencias -> {
                    setCurrentFragment(listaIncidenciasFragment)
                    true
                }
                R.id.home ->{
                    setCurrentFragment(bienvenidoFragment)

                    true
                }
                R.id.notificaciones ->{
                    setCurrentFragment(notificacionesFragment)
                    true
                }
                else -> {false}
            }
        }

    }

    companion object{
        var perfil: PerfilDataResponse? =null

    }

}