package com.example.miincidencia

import android.os.Bundle
import android.security.AppUriAuthenticationPolicy
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.miincidencia.Dataclases.IncidenciaDataResponse
import com.example.miincidencia.Dataclases.PerfilDataResponse
import com.example.miincidencia.Dataclases.incidenciasSubtipoDataResponse
import com.example.miincidencia.api.ApiService
import com.example.miincidencia.databinding.ActivityMainBinding
import com.example.miincidencia.inicio.BienvenidoFragment
import com.example.miincidencia.inicio.getRetrofit
import com.example.miincidencia.listadoIncidencias.ListaIncidenciasFragment
import com.example.miincidencia.notificaciones.NotificacionesFragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import java.lang.Thread.sleep

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var listaIncidenciasFragment: ListaIncidenciasFragment
    lateinit var bienvenidoFragment: BienvenidoFragment
    lateinit var notificacionesFragment: NotificacionesFragment
    var cambios = true
    var obtenidos=false


    lateinit var retrofit: Retrofit
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        retrofit = getRetrofit()
        perfil = Companion.perfil
        buscarIncidencias()
        buscarTipos()
        initComponents()

        setCurrentFragment(bienvenidoFragment)

        initUI()

    }

    private fun initUI() {
        seleccionarToolbar()

    }

    private fun initComponents() {
        listaIncidenciasFragment = ListaIncidenciasFragment()
        bienvenidoFragment = BienvenidoFragment()
        notificacionesFragment = NotificacionesFragment()
        Log.i("prueba2", "salida2")
    }

    private fun setCurrentFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.containerView, fragment)
            commit()
            Log.i("prueba3", "salida3")
        }
    }

    private fun seleccionarToolbar() {
        binding.navegacion.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.incidencias -> {

                    setCurrentFragment(listaIncidenciasFragment)
                    true
                }

                R.id.home -> {

                    setCurrentFragment(bienvenidoFragment)
                    true
                }

                R.id.notificaciones -> {
                    setCurrentFragment(notificacionesFragment)
                    true
                }

                else -> {
                    false
                }
            }
        }
    }

    companion object {
        var perfil: PerfilDataResponse? = null
        var url: String? = null
        var lista:List<IncidenciaDataResponse> = emptyList()
        var tipos:List<incidenciasSubtipoDataResponse> = emptyList()
    }

    fun buscarTipos(){
        if (!obtenidos){
        CoroutineScope(Dispatchers.IO).launch {

        var myResponse=retrofit.create(ApiService::class.java).getSubtipos()
            if (myResponse.isSuccessful){
              var  response= myResponse.body()
                if (response!=null){
                    tipos=response}
            }
        }}
    }
    fun buscarIncidencias() {
        if (cambios&& perfil!=null) {
            var myResponse: Response<List<IncidenciaDataResponse>>

            CoroutineScope(Dispatchers.IO).launch {
                if(perfil?.perfil.equals("admnistrador")){
                myResponse =
                    retrofit.create(ApiService::class.java).getIncidencias()
                }else{
                    myResponse=retrofit.create(ApiService::class.java).getPorCreador(perfil!!.personal_id)}
                if (myResponse.isSuccessful) {
                    val response: List<IncidenciaDataResponse>? = myResponse.body()
                    if (response != null) {

                        lista = response
                        Log.i("pruebas lista", lista.count().toString())
                        cambios = false
                    }
                }
            }
            }

        }
    }


