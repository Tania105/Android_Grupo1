package com.example.miincidencia.listadoIncidencias

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.miincidencia.R
import com.example.miincidencia.databinding.FragmentCerradoBinding
import com.example.miincidencia.databinding.FragmentNuevoBinding

/**
 * A simple [Fragment] subclass.
 * Use the [CerradoFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class CerradoFragment : Fragment() {
    lateinit var binding: FragmentCerradoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCerradoBinding.inflate(inflater, container, false)
        // Inflar el layout del fragmento
        initUi()


        return binding.root
    }
    private fun initUi(){
        setHasOptionsMenu(true)
        // Configurar la barra de acciones para mostrar el botón de "volver"
        val activity = requireActivity() as AppCompatActivity

    }

}